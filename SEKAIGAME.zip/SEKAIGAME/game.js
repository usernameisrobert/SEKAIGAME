import * as planck from 'https://cdn.jsdelivr.net/npm/planck@1.3.0/+esm';
import earcut from 'https://cdn.jsdelivr.net/npm/earcut@3.0.2/+esm';
const PHYSICS_SCALE=32,GRID=2048,CELL=2,WORLD=GRID*CELL;
const CHUNK_PIXELS=64,CHUNK_CELLS=CHUNK_PIXELS/CELL,CHUNKS=GRID/CHUNK_CELLS,CHUNK_UPDATE_RADIUS=3;
const MATERIAL_COLORS=[[0,0,0],[211,166,83],[40,139,214],[98,101,108],[63,135,48],[121,79,45],[104,66,34],[42,111,48]];
const materialCanvas=document.createElement('canvas');
materialCanvas.width=materialCanvas.height=GRID;
const materialContext=materialCanvas.getContext('2d'),materialPixels=materialContext.createImageData(GRID,GRID),renderedMaterials=new Uint8Array(GRID*GRID).fill(255);
let fpsPrevious=0,fpsElapsed=0,fpsFrames=0,measuredFps=0,tune={};
const controlNames=['left','right','up','down','a','b','x','y','lb','rb'];
function readSetting(category,id,fallback){return fallback;}

const isRigid = type => type >= 3 && type <= 7;

const isSolid = type => type === 1 || isRigid(type);

const materialColor = function materialColor(type,shade=0) {
  const c=MATERIAL_COLORS[type] || MATERIAL_COLORS[3];
  return `rgb(${c[0]+shade},${c[1]+shade},${c[2]+shade})`;
};

const wakeArea = function wakeArea(s, x0, y0, x1=x0, y1=y0) {
  const left=Math.max(0,Math.floor((x0-1)/CHUNK_CELLS)),right=Math.min(CHUNKS-1,Math.floor((x1+1)/CHUNK_CELLS));
  const top=Math.max(0,Math.floor((y0-1)/CHUNK_CELLS)),bottom=Math.min(CHUNKS-1,Math.floor((y1+1)/CHUNK_CELLS));
  for(let y=top;y<=bottom;y++) for(let x=left;x<=right;x++) s.chunkAwake[y*CHUNKS+x]=4;
};

const wakePlayerArea = function wakePlayerArea(s) {
  const bounds=[Math.floor(s.x/CELL)-1,Math.floor(s.y/CELL)-1,Math.ceil((s.x+16)/CELL)+1,Math.ceil((s.y+16)/CELL)+1];
  if(!s.playerChunkBounds || s.playerChunkBounds.some((n,i)=>n!==bounds[i])) {
    if(s.playerChunkBounds) wakeArea(s,...s.playerChunkBounds);
    wakeArea(s,...bounds);
    s.playerChunkBounds=bounds;
  }
};

const changeMaterial = function changeMaterial(s,i,type) {
  const old=s.grid[i];
  if(old===type) return;
  s.grid[i]=type;
  if(isRigid(old) && !isRigid(type)) s.terrainPins.delete(i);
  wakeArea(s,i%GRID,Math.floor(i/GRID));
  if(isRigid(old) && !isRigid(type)) {
    s.connectivityDirty=true;
    const seeds=s.supportSeeds || (s.supportSeeds=new Set()),x=i%GRID;
    if(x>0) seeds.add(i-1);
    if(x<GRID-1) seeds.add(i+1);
    if(i>=GRID) seeds.add(i-GRID);
    if(i<GRID*(GRID-1)) seeds.add(i+GRID);
  }
  if(isSolid(old) || isSolid(type)) {
    s.terrainDirty=true;
    s.dirtyTerrainChunks.add(Math.floor(i/GRID/CHUNK_CELLS)*CHUNKS+Math.floor((i%GRID)/CHUNK_CELLS));
  }
};

const findTerrainPins = function findTerrainPins(grid) {
  const seen=new Uint8Array(grid.length),queue=new Uint32Array(grid.length),pins=new Set();
  let head=0,tail=0;
  const visit=i=>{
    if(!seen[i] && isRigid(grid[i])) {seen[i]=1;queue[tail++]=i;}
  };
  const expand=i=>{
    const x=i%GRID;
    if(x>0) visit(i-1);
    if(x<GRID-1) visit(i+1);
    if(i>=GRID) visit(i-GRID);
    if(i<grid.length-GRID) visit(i+GRID);
  };
  // Mark every rigid cell already supported by the world bottom.
  for(let x=0;x<GRID;x++) visit(grid.length-GRID+x);
  while(head<tail) expand(queue[head++]);
  // Each remaining face-connected island receives one destructible anchor.
  for(let seed=0;seed<grid.length;seed++) {
    if(seen[seed] || !isRigid(grid[seed])) continue;
    head=0;tail=0;visit(seed);
    let sumX=0,sumY=0;
    while(head<tail) {
      const i=queue[head++];
      sumX+=i%GRID;sumY+=Math.floor(i/GRID);
      expand(i);
    }
    const cx=sumX/tail,cy=sumY/tail;
    let nearest=seed,best=Infinity;
    for(let n=0;n<tail;n++) {
      const i=queue[n],distance=(i%GRID-cx)**2+(Math.floor(i/GRID)-cy)**2;
      if(distance<best) {best=distance;nearest=i;}
    }
    pins.add(nearest);
  }
  return pins;
};

const makeMaterials = function makeMaterials() {
  const grid = new Uint8Array(GRID * GRID);
  const seed=Math.floor(Math.random()*2147483646)+1;
  let rng=seed;
  const random=()=>((rng=Math.imul(rng,1664525)+1013904223|0)>>>0)/4294967296;
  const surface=new Uint16Array(GRID);
  // Fixed grassy approach and mountain silhouette; all coordinates are material cells.
  for(let x=0;x<GRID;x++) {
    surface[x]=x<90?360:x<300?Math.round(360-(x-90)*0.48):x<460?Math.round(259+(x-300)*0.32):310;
    for(let y=surface[x];y<GRID;y++) grid[y*GRID+x]=y<surface[x]+3?4:y<surface[x]+30?5:3;
  }
  function carve(cx,cy,rx,ry) {
    for(let y=Math.max(1,Math.floor(cy-ry));y<=Math.min(GRID-18,Math.ceil(cy+ry));y++)
      for(let x=Math.max(12,Math.floor(cx-rx));x<=Math.min(GRID-13,Math.ceil(cx+rx));x++)
        if(((x-cx)/rx)**2+((y-cy)/ry)**2<=1) grid[y*GRID+x]=0;
  }
  function tunnel(a,b,rx,ry) {
    const steps=Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/4);
    for(let i=0;i<=steps;i++) {const t=steps?i/steps:0;carve(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,rx,ry);}
  }
  // Every underground chamber joins its row and the row above.
  const rooms=[];
  for(let row=0;row<9;row++) {
    const band=[];
    for(let col=0;col<10;col++) {
      const room={x:90+col*200+(random()-0.5)*70,y:520+row*163+(random()-0.5)*65,rx:35+random()*36,ry:23+random()*20};
      band.push(room);
      carve(room.x,room.y,room.rx,room.ry);
      if(col) {
        const previous=band[col-1],bend={x:(previous.x+room.x)/2,y:(previous.y+room.y)/2+(random()-0.5)*60};
        tunnel(previous,bend,13,12);tunnel(bend,room,13,12);
      }
      if(row) {
        const above=rooms[row-1][col],bend={x:room.x+(random()-0.5)*65,y:(above.y+room.y)/2};
        tunnel(above,bend,12,13);tunnel(bend,room,12,13);
      }
    }
    rooms.push(band);
  }
  // Random terrain starts below the authored entrance, never inside the start area.
  tunnel({x:250,y:450},rooms[0][1],16,14);
  tunnel({x:250,y:450},rooms[0][0],16,14);
  // Fixed open mouth, sheltered passage, then a descending mine entrance.
  tunnel({x:96,y:346},{x:170,y:346},15,13);
  tunnel({x:170,y:346},{x:250,y:450},15,13);
  // Two rooted trees on the fixed approach; no random geometry near spawn.
  for(const tx of [18,68]) {
    const ground=surface[tx],top=ground-29,radius=11;
    for(let y=top-radius;y<=top+radius;y++) for(let x=tx-radius;x<=tx+radius;x++) {
      if(x>=0 && x<GRID && y>=0 && y<surface[x] && ((x-tx)/radius)**2+((y-top)/radius)**2<=1) grid[y*GRID+x]=7;
    }
    for(let y=top;y<=ground;y++) for(let x=tx-1;x<=tx+1;x++) grid[y*GRID+x]=6;
  }
  // Shallow deposits occupy existing chamber floors, not connecting passages.
  for(const band of rooms) for(const room of band) {
    const type=random()<0.5?1:2;
    const bottom=Math.floor(room.y+room.ry);
    for(let y=bottom-7;y<=bottom;y++) for(let x=Math.ceil(room.x-room.rx);x<=Math.floor(room.x+room.rx);x++)
      if(!grid[y*GRID+x]) grid[y*GRID+x]=type;
  }
  const terrainPins=findTerrainPins(grid);
  const physics = new planck.World(planck.Vec2(0, 650 / PHYSICS_SCALE));
  const chunkAwake=new Uint8Array(CHUNKS*CHUNKS);
  for(let i=0;i<grid.length;i++) if(grid[i]===1 || grid[i]===2)
    chunkAwake[Math.floor(i/GRID/CHUNK_CELLS)*CHUNKS+Math.floor((i%GRID)/CHUNK_CELLS)]=4;
  return {grid, terrainPins, physics,seed,surface,connectivityDirty:false,dirtyTerrainChunks:new Set(Array.from({length:CHUNKS*CHUNKS},(_,i)=>i)), chunkAwake, chunkScanned:0, rockBodies: [], dynamicRock: new Uint32Array(grid.length), dynamicIndices:[], terrainBody: null, terrainDirty: true, terrainAge: 0, rockSerial: 0, previousMaterials: grid.slice(), disconnectedRock: new Uint8Array(grid.length), disconnectedRockCount: 0, moved: new Uint32Array(GRID * GRID), tick: 0, flying: [], accumulator: 0, launched: 0, submerged: 0, waterContact: false, splashCooldown: 0, heldWater: 0, dripTime: 0};
};

const updateRigidConnectivity = function updateRigidConnectivity(s) {
  const grid=s.grid,seeds=s.supportSeeds;
  if(!seeds || (!seeds.size && !s.supportSearch)) return;
  if(s.connectivityDirty) {
    if(s.supportSearch) seeds.add(s.supportSearch.seed);
    s.supportSearch=null;
    s.connectivityDirty=false;
  }
  const marks=s.supportMarks || (s.supportMarks=new Uint32Array(grid.length));
  let budget=12000;
  while(budget>0 && (seeds.size || s.supportSearch)) {
    if(!s.supportSearch) {
      const seed=seeds.values().next().value;
      seeds.delete(seed);
      if(!isRigid(grid[seed])) continue;
      s.supportStamp=((s.supportStamp || 0)+1)>>>0;
      if(!s.supportStamp) {marks.fill(0);s.supportStamp=1;}
      marks[seed]=s.supportStamp;
      s.supportSearch={seed,stack:[seed],cells:[],stamp:s.supportStamp};
    }
    const job=s.supportSearch;
    while(budget>0 && job.stack.length) {
      budget--;
      const i=job.stack.pop(),x=i%GRID;
      job.cells.push(i);
      seeds.delete(i);
      if(i>=grid.length-GRID || s.terrainPins.has(i)) {s.supportSearch=null;break;}
      const visit=j=>{
        if(isRigid(grid[j]) && marks[j]!==job.stamp) {marks[j]=job.stamp;job.stack.push(j);}
      };
      // Depth-first downward search finds grounded terrain without scanning the world.
      if(i>=GRID) visit(i-GRID);
      if(x>0) visit(i-1);
      if(x<GRID-1) visit(i+1);
      visit(i+GRID);
    }
    if(!s.supportSearch || job.stack.length) continue;
    const cells=job.cells.map(i=>({x:i%GRID,y:Math.floor(i/GRID),type:grid[i],shade:(i*17+Math.floor(i/GRID)*13)%19}));
    const rock=createRockBody(s,cells);
    if(rock) {
      for(const i of job.cells) {
        grid[i]=0;seeds.delete(i);s.disconnectedRock[i]=0;
        const x=i%GRID,y=Math.floor(i/GRID);
        wakeArea(s,x,y);
        s.dirtyTerrainChunks.add(Math.floor(y/CHUNK_CELLS)*CHUNKS+Math.floor(x/CHUNK_CELLS));
      }
      s.terrainDirty=true;
      rasterizeRock(s);
    }
    s.supportSearch=null;
  }
};

const rockContours = function rockContours(cells) {
  const mask = new Set(cells.map(p => `${p.x},${p.y}`));
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of cells) {minX = Math.min(minX, p.x); minY = Math.min(minY, p.y); maxX = Math.max(maxX, p.x); maxY = Math.max(maxY, p.y);}
  const segments = [], links = new Map();
  const lookup = {1:[[3,0]],2:[[0,1]],3:[[3,1]],4:[[1,2]],5:[[3,0],[1,2]],6:[[0,2]],7:[[3,2]],8:[[2,3]],9:[[2,0]],10:[[0,1],[2,3]],11:[[2,1]],12:[[1,3]],13:[[1,0]],14:[[0,3]]};
  const key = p => `${p[0]},${p[1]}`;
  function add(a,b) {
    const id = segments.length; segments.push([a,b]);
    for (const p of [a,b]) {const k=key(p); if (!links.has(k)) links.set(k,[]); links.get(k).push(id);}
  }
  for (let y=minY-1;y<=maxY;y++) for (let x=minX-1;x<=maxX;x++) {
    const code = Number(mask.has(`${x},${y}`)) | (Number(mask.has(`${x+1},${y}`))<<1) | (Number(mask.has(`${x+1},${y+1}`))<<2) | (Number(mask.has(`${x},${y+1}`))<<3);
    const edges=[[x+1,y+0.5],[x+1.5,y+1],[x+1,y+1.5],[x+0.5,y+1]];
    for (const pair of lookup[code] || []) add(edges[pair[0]],edges[pair[1]]);
  }
  const used = new Set(), loops=[];
  for (let first=0;first<segments.length;first++) {
    if (used.has(first)) continue;
    const ring=[], start=segments[first][0]; let p=start, id=first;
    while (!used.has(id)) {
      used.add(id); ring.push(p);
      const seg=segments[id]; p=key(seg[0])===key(p)?seg[1]:seg[0];
      if (key(p)===key(start)) break;
      id=(links.get(key(p)) || []).find(n=>!used.has(n));
      if (id===undefined) break;
    }
    let simplified=ring, changed=true;
    while(changed && simplified.length>3) {
      changed=false; const next=[];
      for(let i=0;i<simplified.length;i++) {
        const a=simplified[(i+simplified.length-1)%simplified.length],b=simplified[i],d=simplified[(i+1)%simplified.length];
        const cross=Math.abs((b[0]-a[0])*(d[1]-b[1])-(b[1]-a[1])*(d[0]-b[0]));
        const span=Math.hypot(d[0]-a[0],d[1]-a[1]);
        const between=(b[0]-a[0])*(b[0]-d[0])+(b[1]-a[1])*(b[1]-d[1])<=0;
        if(cross<1e-8 || (between && span>0 && cross/span<=0.3 && simplified.length-next.length>3)) changed=true;
        else next.push(b);
      }
      if(next.length<3) break; simplified=next;
    }
    if(simplified.length>=3) loops.push(simplified);
  }
  const area=ring=>Math.abs(ring.reduce((n,p,i)=>{const q=ring[(i+1)%ring.length];return n+p[0]*q[1]-q[0]*p[1];},0));
  return loops.sort((a,b)=>area(b)-area(a));
};

const mergeRockTriangles = function mergeRockTriangles(vertices, triangles) {
  const polygons=[];
  for(let i=0;i<triangles.length;i+=3) polygons.push(triangles.slice(i,i+3));
  const cross=(a,b,d)=>(vertices[b*2]-vertices[a*2])*(vertices[d*2+1]-vertices[b*2+1])-(vertices[b*2+1]-vertices[a*2+1])*(vertices[d*2]-vertices[b*2]);
  // Merge only shared-edge convex neighbors; preserve holes and boundary geometry.
  let changed=true;
  while(changed) {
    changed=false;
    const edges=new Map();
    search: for(let i=0;i<polygons.length;i++) {
      const a=polygons[i];
      for(let e=0;e<a.length;e++) {
        const u=a[e],v=a[(e+1)%a.length],other=edges.get(`${v}:${u}`);
        if(other) {
          const b=polygons[other.i],f=other.e,joined=[];
          for(let k=1;k<=a.length;k++) joined.push(a[(e+k)%a.length]);
          for(let k=2;k<b.length;k++) joined.push(b[(f+k)%b.length]);
          let sign=0,convex=joined.length<=8;
          for(let k=0;convex && k<joined.length;k++) {
            const turn=cross(joined[k],joined[(k+1)%joined.length],joined[(k+2)%joined.length]);
            if(Math.abs(turn)<1e-8) continue;
            if(sign && Math.sign(turn)!==sign) convex=false;
            sign=Math.sign(turn);
          }
          if(convex && sign) {polygons[other.i]=joined;polygons.splice(i,1);changed=true;break search;}
        }
        edges.set(`${u}:${v}`,{i,e});
      }
    }
  }
  return polygons;
};

const createRockBody = function createRockBody(s, worldCells, inherited) {
  if (!worldCells.length) return;
  let ox=Infinity,oy=Infinity;
  for(const p of worldCells) {ox=Math.min(ox,p.x);oy=Math.min(oy,p.y);}
  const cells=worldCells.map(p=>({x:p.x-ox,y:p.y-oy,type:p.type ?? 3,shade:p.shade ?? ((p.y*GRID+p.x)*17+p.y*13)%19}));
  const loops=rockContours(cells), vertices=[],holes=[];
  for(let i=0;i<loops.length;i++) {if(i) holes.push(vertices.length/2);for(const p of loops[i]) vertices.push(p[0]*CELL,p[1]*CELL);}
  const triangles=earcut(vertices,holes,2);
  if(!triangles.length) return;
  const origin=inherited ? inherited.body.getWorldPoint(planck.Vec2(ox*CELL/PHYSICS_SCALE,oy*CELL/PHYSICS_SCALE)) : planck.Vec2(ox*CELL/PHYSICS_SCALE,oy*CELL/PHYSICS_SCALE);
  const body=s.physics.createDynamicBody({position:origin,angle:inherited?inherited.body.getAngle():0,bullet:true,angularDamping:0.12,linearDamping:0.025});
  for(const polygon of mergeRockTriangles(vertices,triangles)) {
    const points=polygon.map(n=>planck.Vec2(vertices[n*2]/PHYSICS_SCALE,vertices[n*2+1]/PHYSICS_SCALE));
    const a=points[0],b=points[1],d=points[2];
    if(Math.abs((b.x-a.x)*(d.y-a.y)-(b.y-a.y)*(d.x-a.x))>1e-8) body.createFixture(planck.Polygon(points),{density:2.5,friction:0.65,restitution:0.02});
  }
  if(inherited) {body.setLinearVelocity(inherited.body.getLinearVelocityFromWorldPoint(body.getWorldCenter()));body.setAngularVelocity(inherited.body.getAngularVelocity());}
  const rock={id:++s.rockSerial,body,cells,loops,triangles:triangles.length/3,mask:new Set(cells.map(p=>`${p.x},${p.y}`))};
  s.rockBodies.push(rock);
  return rock;
};

const rasterizeRock = function rasterizeRock(s) {
  for(const i of s.dynamicIndices) s.dynamicRock[i]=0;
  s.dynamicIndices.length=0;
  s.disconnectedRockCount=0;
  for(const rock of s.rockBodies) {
    s.disconnectedRockCount+=rock.cells.length;
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    for(const ring of rock.loops) for(const p of ring) {const q=rock.body.getWorldPoint(planck.Vec2(p[0]*CELL/PHYSICS_SCALE,p[1]*CELL/PHYSICS_SCALE)); minX=Math.min(minX,q.x*PHYSICS_SCALE);maxX=Math.max(maxX,q.x*PHYSICS_SCALE);minY=Math.min(minY,q.y*PHYSICS_SCALE);maxY=Math.max(maxY,q.y*PHYSICS_SCALE);}
    const position=rock.body.getPosition(),angle=rock.body.getAngle();
    if(!rock.chunkPose || rock.chunkPose[0]!==position.x || rock.chunkPose[1]!==position.y || rock.chunkPose[2]!==angle) {
      if(rock.chunkBounds) wakeArea(s,...rock.chunkBounds);
      rock.chunkBounds=[minX/CELL,minY/CELL,maxX/CELL,maxY/CELL];
      wakeArea(s,...rock.chunkBounds);
      rock.chunkPose=[position.x,position.y,angle];
    }
    for(let y=Math.max(0,Math.floor(minY/CELL));y<=Math.min(GRID-1,Math.floor(maxY/CELL));y++) for(let x=Math.max(0,Math.floor(minX/CELL));x<=Math.min(GRID-1,Math.floor(maxX/CELL));x++) {
      const p=rock.body.getLocalPoint(planck.Vec2((x*CELL+1)/PHYSICS_SCALE,(y*CELL+1)/PHYSICS_SCALE));
      if(rock.mask.has(`${Math.floor(p.x*PHYSICS_SCALE/CELL)},${Math.floor(p.y*PHYSICS_SCALE/CELL)}`)) {const i=y*GRID+x;s.dynamicRock[i]=rock.id;s.dynamicIndices.push(i);}
    }
  }
};

const rebuildRockTerrain = function rebuildRockTerrain(s) {
  const body=s.terrainBody || (s.terrainBody=s.physics.createBody());
  const chunks=s.terrainFixtures || (s.terrainFixtures=new Map());
  for(const id of s.dirtyTerrainChunks) {
    const old=chunks.get(id)||new Map(),fixtures=new Map();
    const x0=(id%CHUNKS)*CHUNK_CELLS,y0=Math.floor(id/CHUNKS)*CHUNK_CELLS;
    let active=new Map();
    const finish=r=>{
      const key=`${r.x}:${r.y}:${r.w}:${r.h}`;
      let fixture=old.get(key);
      if(fixture) old.delete(key);
      else fixture=body.createFixture(planck.Box(r.w*CELL/PHYSICS_SCALE/2,r.h*CELL/PHYSICS_SCALE/2,planck.Vec2((r.x+r.w/2)*CELL/PHYSICS_SCALE,(r.y+r.h/2)*CELL/PHYSICS_SCALE)),{friction:0.65});
      fixtures.set(key,fixture);
    };
    for(let y=y0;y<y0+CHUNK_CELLS;y++) {
      const next=new Map();
      for(let x=x0;x<x0+CHUNK_CELLS;) {
        if(!isSolid(s.grid[y*GRID+x])) {x++;continue;}
        const start=x;while(x<x0+CHUNK_CELLS && isSolid(s.grid[y*GRID+x])) x++;
        const k=`${start}:${x-start}`,r=active.get(k)||{x:start,y,w:x-start,h:0};
        r.h++;next.set(k,r);
      }
      for(const [k,r] of active) if(!next.has(k)) finish(r);
      active=next;
    }
    for(const r of active.values()) finish(r);
    for(const fixture of old.values()) body.destroyFixture(fixture);
    chunks.set(id,fixtures);
  }
  s.dirtyTerrainChunks.clear();
  if(!s.terrainBounds) {
  body.createFixture(planck.Edge(planck.Vec2(0,0),planck.Vec2(WORLD/PHYSICS_SCALE,0)));
  body.createFixture(planck.Edge(planck.Vec2(0,0),planck.Vec2(0,WORLD/PHYSICS_SCALE)));
  body.createFixture(planck.Edge(planck.Vec2(WORLD/PHYSICS_SCALE,0),planck.Vec2(WORLD/PHYSICS_SCALE,WORLD/PHYSICS_SCALE)));
  body.createFixture(planck.Edge(planck.Vec2(0,WORLD/PHYSICS_SCALE),planck.Vec2(WORLD/PHYSICS_SCALE,WORLD/PHYSICS_SCALE)));
  s.terrainBounds=true;
  }
  s.terrainDirty=false;s.terrainAge=0;
};

const stepRockBodies = function stepRockBodies(s,h) {
  updateRigidConnectivity(s);
  s.terrainAge+=h;
  if(s.terrainDirty) rebuildRockTerrain(s);
  if(!s.playerRockCollider) {
    s.playerRockCollider=s.physics.createDynamicBody({position:planck.Vec2((s.x+8)/PHYSICS_SCALE,(s.y+8)/PHYSICS_SCALE),fixedRotation:true,bullet:true,gravityScale:0,allowSleep:false});
    s.playerRockCollider.createFixture(planck.Box(8/PHYSICS_SCALE,8/PHYSICS_SCALE),{density:2.5,friction:0.65,restitution:0});
  }
  const player=s.playerRockCollider;
  player.setLinearVelocity(planck.Vec2(s.vx/PHYSICS_SCALE,s.vy/PHYSICS_SCALE));
  s.physics.setGravity(planck.Vec2(0,tune.gravity/PHYSICS_SCALE));
  s.physics.step(h,8,3);
  const position=player.getPosition(),velocity=player.getLinearVelocity();
  s.x=position.x*PHYSICS_SCALE-8;
  s.y=position.y*PHYSICS_SCALE-8;
  s.vx=velocity.x*PHYSICS_SCALE;
  s.vy=velocity.y*PHYSICS_SCALE;
  s.grounded=false;s.supportVx=0;s.supportVy=0;
  for(let edge=player.getContactList();edge;edge=edge.next) {
    const contact=edge.contact;
    if(!contact.isTouching() || !contact.isEnabled()) continue;
    const manifold=contact.getWorldManifold(null);
    if(!manifold || !manifold.points.length) continue;
    const playerIsA=contact.getFixtureA().getBody()===player;
    if(manifold.normal.y*(playerIsA?1:-1)<0.55) continue;
    const other=playerIsA?contact.getFixtureB().getBody():contact.getFixtureA().getBody();
    const support=other.getLinearVelocityFromWorldPoint(manifold.points[0]);
    if(s.vy-support.y*PHYSICS_SCALE < -20) continue;
    s.grounded=true;
    s.supportVx=support.x*PHYSICS_SCALE;s.supportVy=support.y*PHYSICS_SCALE;
    s.coyote=0.1;
  }
  rasterizeRock(s);
};

const destroyMovingRock = function destroyMovingRock(s,cx,cy) {
  for(const rock of [...s.rockBodies]) {
    const remaining=[],removed=[];
    for(const p of rock.cells) {
      const q=rock.body.getWorldPoint(planck.Vec2((p.x*CELL+1)/PHYSICS_SCALE,(p.y*CELL+1)/PHYSICS_SCALE));
      if(Math.hypot(q.x*PHYSICS_SCALE-cx,q.y*PHYSICS_SCALE-cy)<=2) removed.push(q);else remaining.push(p);
    }
    if(!removed.length) continue;
    if(rock.chunkBounds) wakeArea(s,...rock.chunkBounds);
    for(const q of removed) {const v=rock.body.getLinearVelocityFromWorldPoint(q);s.flying.push({x:q.x*PHYSICS_SCALE,y:q.y*PHYSICS_SCALE,vx:v.x*PHYSICS_SCALE,vy:v.y*PHYSICS_SCALE,type:1,settleDelay:0.08,pickupDelay:0});s.converted++;}
    const pool=new Map(remaining.map(p=>[`${p.x},${p.y}`,p]));
    while(pool.size) {
      const seed=pool.values().next().value, part=[seed];pool.delete(`${seed.x},${seed.y}`);
      for(let i=0;i<part.length;i++) {const p=part[i];for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {const k=`${p.x+dx},${p.y+dy}`,n=pool.get(k);if(n){pool.delete(k);part.push(n);}}}
      createRockBody(s,part,rock);
    }
    s.physics.destroyBody(rock.body);s.rockBodies.splice(s.rockBodies.indexOf(rock),1);
  }
  rasterizeRock(s);
};

const cameraFor = function cameraFor(s) {
  const size = 256;
  return {
    x: Math.max(0, Math.min(WORLD - size, s.x + 8 - size / 2)),
    y: Math.max(0, Math.min(WORLD - size, s.y + 8 - size / 2)),
    size
  };
};

const readTune = function readTune() {
  tune.speed = readSetting('tune', 'run-speed', 100, {min: 40, max: 180, step: 5, editorOrder: 1});
  tune.jump = readSetting('tune', 'jump-speed', 270, {min: 200, max: 350, step: 5, editorOrder: 2});
  tune.gravity = readSetting('tune', 'gravity', 650, {min: 400, max: 1100, step: 25, editorOrder: 3});
};

const paint = function paint(c) {
  for (const name of controlNames) {
    const element = document.getElementById(name);
    const value = String(Boolean(c.state.held[name]));
    if (element.dataset.held !== value) {
      element.dataset.held = value;
    }
  }
};

const jump = function jump(c) {
  const s = c.state;
  if (s.coyote <= 0 && s.submerged < 0.15) {
    return;
  }
  s.vy = -tune.jump * (s.submerged > 0.15 ? 0.6 : 1) + (s.grounded ? (s.supportVy || 0) : 0);
  s.grounded = false;
  s.coyote = 0;
  s.jumps += 1;
  burst(s, s.x + 8, s.y + 17, 13, 0, -95, 1, 1 + Math.floor(Math.random() * 2));
};

const insidePlayer = function insidePlayer(s, x, y) {
  return x * CELL < s.x + 16 && (x + 1) * CELL > s.x && y * CELL < s.y + 16 && (y + 1) * CELL > s.y;
};

const launch = function launch(s, x, y, vx, vy) {
  const i = y * GRID + x, type = s.grid[i];
  if (!type || isRigid(type)) return;
  if(type===1) s.terrainDirty=true;
  changeMaterial(s,i,0);
  s.flying.push({x: x * CELL + 1, y: y * CELL + 1, vx, vy, type, settleDelay: 0.08, pickupDelay: type === 2 ? 0.2 : 0});
  s.launched++;
};

const burst = function burst(s, cx, cy, radius, vx, vy, material = 0, limit = 2) {
  const candidates = [];
  for (let y = Math.max(0, Math.floor((cy - radius) / CELL)); y <= Math.min(GRID - 1, (cy + radius) / CELL); y++) {
    for (let x = Math.max(0, Math.floor((cx - radius) / CELL)); x <= Math.min(GRID - 1, (cx + radius) / CELL); x++) {
      const dx = x * CELL + 1 - cx, dy = y * CELL + 1 - cy;
      if (dx * dx + dy * dy > radius * radius || !s.grid[y * GRID + x] || isRigid(s.grid[y * GRID + x])) continue;
      if (material && s.grid[y * GRID + x] !== material) continue;
      candidates.push({x, y, dx, dy, distance: dx * dx + dy * dy});
    }
  }
  candidates.sort((a, b) => a.distance - b.distance);
  const nearby = candidates.slice(0, Math.max(limit * 3, limit));
  for (let i = nearby.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [nearby[i], nearby[j]] = [nearby[j], nearby[i]];
  }
  for (const p of nearby.slice(0, limit)) {
    launch(s, p.x, p.y, vx + p.dx * 7 + (Math.random() - 0.5) * 35, vy - Math.random() * 65);
  }
};

const stepMaterials = function stepMaterials(s, h) {
  const g = s.grid, moved = s.moved, tick = ++s.tick;
  const playerChunkX=Math.max(0,Math.min(CHUNKS-1,Math.floor((s.x+8)/CHUNK_PIXELS)));
  const playerChunkY=Math.max(0,Math.min(CHUNKS-1,Math.floor((s.y+8)/CHUNK_PIXELS)));
  const minChunkX=Math.max(0,playerChunkX-CHUNK_UPDATE_RADIUS),maxChunkX=Math.min(CHUNKS-1,playerChunkX+CHUNK_UPDATE_RADIUS);
  const minChunkY=Math.max(0,playerChunkY-CHUNK_UPDATE_RADIUS),maxChunkY=Math.min(CHUNKS-1,playerChunkY+CHUNK_UPDATE_RADIUS);
  const minCellX=minChunkX*CHUNK_CELLS,maxCellX=(maxChunkX+1)*CHUNK_CELLS;
  const minCellY=minChunkY*CHUNK_CELLS,maxCellY=(maxChunkY+1)*CHUNK_CELLS;
  const active=new Uint8Array(CHUNKS*CHUNKS);
  s.chunkScanned=0;
  for(let cy=minChunkY;cy<=maxChunkY;cy++) for(let cx=minChunkX;cx<=maxChunkX;cx++) {
    const i=cy*CHUNKS+cx;
    if(s.chunkAwake[i]) {active[i]=s.chunkAwake[i];s.chunkAwake[i]--;s.chunkScanned++;}
  }
  function move(x, y, nx, ny, type) {
    if (nx < minCellX || nx >= maxCellX || ny < minCellY || ny >= maxCellY || insidePlayer(s, nx, ny) || s.dynamicRock[ny * GRID + nx]) return false;
    const a = y * GRID + x, b = ny * GRID + nx, other = g[b];
    if (other && !(type === 1 && other === 2)) return false;
    if(type===1 || other===1) {
      s.terrainDirty=true;
      s.dirtyTerrainChunks.add(Math.floor(y/CHUNK_CELLS)*CHUNKS+Math.floor(x/CHUNK_CELLS));
      s.dirtyTerrainChunks.add(Math.floor(ny/CHUNK_CELLS)*CHUNKS+Math.floor(nx/CHUNK_CELLS));
    }
    g[a] = other; g[b] = type; moved[a] = moved[b] = tick;
    wakeArea(s,x,y);
    wakeArea(s,nx,ny);
    return true;
  }
  for (let y = maxCellY - 1; y >= minCellY; y--) {
    const chunkRow=Math.floor(y/CHUNK_CELLS)*CHUNKS;
    let rowActive=false;
    for(let cx=minChunkX;cx<=maxChunkX;cx++) if(active[chunkRow+cx]) {rowActive=true;break;}
    if(!rowActive) {y-=y%CHUNK_CELLS;continue;}
    const reverse = (tick + y) % 2;
    for (let k = 0; k < maxCellX-minCellX; k++) {
      const x = reverse ? maxCellX - 1 - k : minCellX + k, i = y * GRID + x, type = g[i];
      if(!active[Math.floor(y/CHUNK_CELLS)*CHUNKS+Math.floor(x/CHUNK_CELLS)]) {
        k+=reverse ? x%CHUNK_CELLS : CHUNK_CELLS-1-x%CHUNK_CELLS;
        continue;
      }
      if (!type || isRigid(type) || moved[i] === tick) continue;
      const d = Math.random() < 0.5 ? -1 : 1;
      if (move(x, y, x, y + 1, type) || move(x, y, x + d, y + 1, type) || move(x, y, x - d, y + 1, type)) continue;
      if (type === 2) {
        const flows=direction=>{
          if(y>0 && g[(y-1)*GRID+x]===2) return true;
          for(let distance=1;distance<maxCellX-minCellX;distance++) {
            const nx=x+direction*distance;
            if(nx<minCellX || nx>=maxCellX || g[y*GRID+nx] || s.dynamicRock[y*GRID+nx] || insidePlayer(s,nx,y)) return false;
            if(y+1<maxCellY && !g[(y+1)*GRID+nx] && !s.dynamicRock[(y+1)*GRID+nx] && !insidePlayer(s,nx,y+1)) return true;
          }
          return false;
        };
        if (!(flows(d) && move(x,y,x+d,y,type)) && flows(-d)) move(x,y,x-d,y,type);
      }
    }
  }
  for (let n = s.flying.length - 1; n >= 0; n--) {
    const p = s.flying[n];
    p.pickupDelay = Math.max(0, (p.pickupDelay || 0) - h);
    p.settleDelay = Math.max(0, (p.settleDelay || 0) - h);
    p.vy += tune.gravity * h;
    const steps = Math.max(1, Math.ceil(Math.hypot(p.vx, p.vy) * h / 0.8));
    let settled = false;
    for (let j = 0; j < steps; j++) {
      const nx = p.x + p.vx * h / steps, ny = p.y + p.vy * h / steps;
      if (ny < 1) {p.y = 1; p.vy = Math.abs(p.vy) * 0.35; break;}
      const gx = Math.floor(nx / CELL), gy = Math.floor(ny / CELL);
      const hit = gx < 0 || gx >= GRID || gy >= GRID || (gy >= 0 && (g[gy * GRID + gx] || s.dynamicRock[gy * GRID + gx]));
      if (hit) {
        if (p.settleDelay > 0) {
          if (gx < 0 || gx >= GRID || gy >= GRID) {
            if (gx < 0 || gx >= GRID) p.vx *= -0.35;
            if (gy >= GRID) p.vy = -Math.abs(p.vy) * 0.35;
            break;
          }
          p.x = nx; p.y = ny;
          continue;
        }
        const ox = Math.max(0, Math.min(GRID - 1, Math.floor(p.x / CELL)));
        const oy = Math.max(0, Math.min(GRID - 1, Math.floor(p.y / CELL)));
        let found = -1;
        for (let r = 0; r <= 5 && found < 0; r++) {
          for (let dy = -r; dy <= r && found < 0; dy++) for (let dx = -r; dx <= r; dx++) {
            const x = ox + dx, y = oy + dy;
            if (x >= 0 && x < GRID && y >= 0 && y < GRID && !g[y * GRID + x] && !s.dynamicRock[y * GRID + x] && !insidePlayer(s, x, y)) {found = y * GRID + x; break;}
          }
        }
        if (found >= 0) {changeMaterial(s,found,p.type); settled = true;}
        else {p.vx *= -0.35; p.vy = -Math.abs(p.vy) * 0.35;}
        break;
      }
      if (gy >= 0 && insidePlayer(s, gx, gy)) {
        if (p.settleDelay > 0) {
          p.x = nx; p.y = ny;
          continue;
        }
        if (p.type === 2 && s.heldWater < 15 && !p.pickupDelay) {
          s.heldWater++;
          settled = true;
          break;
        }
        p.vx = (p.x < s.x + 8 ? -1 : 1) * Math.max(35, Math.abs(s.vx));
        p.vy = -Math.abs(p.vy) * 0.4;
        break;
      }
      p.x = nx; p.y = ny;
    }
    if (settled) s.flying.splice(n, 1);
  }
};

const sandCollision = function sandCollision(s) {
  if (s.x < 0 || s.x + 16 > WORLD || s.y + 16 > WORLD) return true;
  for (let y = Math.max(0, Math.floor(s.y / CELL)); y <= Math.min(GRID - 1, Math.ceil((s.y + 16) / CELL) - 1); y++)
    for (let x = Math.max(0, Math.floor(s.x / CELL)); x <= Math.min(GRID - 1, Math.ceil((s.x + 16) / CELL) - 1); x++)
      if (isSolid(s.grid[y * GRID + x]) || s.dynamicRock[y * GRID + x]) return true;
  return false;
};

const movePlayer = function movePlayer(s, distance, axis) {
  const steps = Math.max(1, Math.ceil(Math.abs(distance) / 0.5));
  for (let n = 0; n < steps; n++) {
    const old = s[axis];
    s[axis] += distance / steps;
    if (sandCollision(s)) {s[axis] = old; return true;}
  }
  return false;
};

const shoot = function shoot(c, targetX, targetY) {
  const s = c.state, x = s.x + 8, y = s.y + 8;
  let dx = targetX - x, dy = targetY - y;
  if (!Number.isFinite(dx) || !Number.isFinite(dy)) return;
  if (Math.hypot(dx, dy) < 1) { dx = s.vx < 0 ? -1 : 1; dy = 0; }
  const length = Math.hypot(dx, dy);
  s.bullets.push({x, y, vx: dx / length * 320, vy: dy / length * 320, life: 3});
  s.shots++;
};

const convertToSand = function convertToSand(s, cx, cy) {
  destroyMovingRock(s,cx,cy);
  s.terrainDirty = true;
  for (let y = Math.max(0, Math.floor((cy - 2) / CELL)); y <= Math.min(GRID - 1, Math.floor((cy + 2) / CELL)); y++) {
    for (let x = Math.max(0, Math.floor((cx - 2) / CELL)); x <= Math.min(GRID - 1, Math.floor((cx + 2) / CELL)); x++) {
      const i = y * GRID + x;
      if (s.grid[i] && Math.hypot(x * CELL + 1 - cx, y * CELL + 1 - cy) <= 2) {
        if (s.grid[i] !== 1) s.converted++;
        changeMaterial(s,i,1);
      }
    }
  }
  for (const p of s.flying) {
    if (Math.hypot(p.x - cx, p.y - cy) <= 2) {
      if (p.type !== 1) s.converted++;
      p.type = 1;
    }
  }
};

const stepBullets = function stepBullets(s, h) {
  for (const hit of s.magicImpacts) hit.life -= h;
  s.magicImpacts = s.magicImpacts.filter(hit => hit.life > 0);
  for (let n = s.bullets.length - 1; n >= 0; n--) {
    const b = s.bullets[n];
    b.life -= h;
    let done = b.life <= 0;
    const steps = Math.max(1, Math.ceil(Math.hypot(b.vx, b.vy) * h / 0.5));
    for (let j = 0; j < steps && !done; j++) {
      b.x += b.vx * h / steps;
      b.y += b.vy * h / steps;
      if (b.x < 0 || b.y < 0 || b.x >= WORLD || b.y >= WORLD) {done = true; break;}
      const gx = Math.floor(b.x / CELL), gy = Math.floor(b.y / CELL);
      if (s.grid[gy * GRID + gx] || s.dynamicRock[gy * GRID + gx]) {
        convertToSand(s, b.x, b.y);
        s.magicImpacts.push({x: b.x, y: b.y, life: 0.25});
        s.magicHits++;
        done = true;
      } else {
        const particle = s.flying.find(p => Math.abs(p.x - b.x) <= 1 && Math.abs(p.y - b.y) <= 1);
        if (particle) {
          convertToSand(s, particle.x, particle.y);
          s.magicImpacts.push({x: particle.x, y: particle.y, life: 0.25});
          s.magicHits++;
          done = true;
        }
      }
    }
    if (done) s.bullets.splice(n, 1);
  }
};

const simulate = function simulate(h, c) {
  const s = c.state;
  const direction = Number(Boolean(s.held.right)) - Number(Boolean(s.held.left));
  const target = direction * tune.speed + (s.grounded ? (s.supportVx || 0) : 0);
  const rate = s.grounded ? (direction ? 1100 : 1400) : (direction ? 600 : 70);
  const change = target - s.vx;
  s.vx += Math.sign(change) * Math.min(Math.abs(change), rate * h);
  s.coyote = s.grounded ? 0.1 : Math.max(0, s.coyote - h);
  const entryVx = s.vx;
  const gravityScale = !s.held.a && s.vy < 0 ? 2.3 : 1;
  s.vy = Math.min(420, s.vy + tune.gravity * (gravityScale - s.submerged * 1.35) * h);
  s.vy *= Math.exp(-s.submerged * 5 * h);
  s.vx *= Math.exp(-s.submerged * 3 * h);
  const impact = s.vy;
  const wasGrounded=s.grounded;
  stepBullets(s,h);
  stepRockBodies(s,h);
  wakePlayerArea(s);
  if(Math.abs(entryVx)>65 && Math.abs(s.vx)<Math.abs(entryVx)*0.5) burst(s,s.x+(entryVx>0?17:-1),s.y+9,7,entryVx*0.8,-45);
  if(!wasGrounded && s.grounded && impact-(s.supportVy || 0)>125) burst(s,s.x+8,s.y+17,Math.min(16,impact/18),s.vx*0.3,-impact*0.45,1,1+Math.floor(Math.random()*2));
  let wet = 0, samples = 0;
  for (let y = Math.max(0, Math.floor(s.y / CELL)); y <= Math.min(GRID - 1, Math.floor((s.y + 15) / CELL)); y++) {
    for (const x of [Math.floor((s.x - 1) / CELL), Math.floor((s.x + 17) / CELL)]) {
      if (x >= 0 && x < GRID) {samples++; if (s.grid[y * GRID + x] === 2) wet++;}
    }
  }
  let immersed = wet / Math.max(1, samples);
  let overlappingWater = 0;
  let contactX = 0, contactY = 0;
  for (let y = Math.max(0, Math.floor((s.y - 1) / CELL)); y <= Math.min(GRID - 1, Math.floor((s.y + 16) / CELL)); y++) {
    for (let x = Math.max(0, Math.floor((s.x - 1) / CELL)); x <= Math.min(GRID - 1, Math.floor((s.x + 16) / CELL)); x++) {
      if (s.grid[y * GRID + x] !== 2) continue;
      // Nearby side water must not consume the next actual entry.
      if (!insidePlayer(s, x, y)) continue;
      overlappingWater++;
      contactX += x * CELL + 1;
      contactY += y * CELL + 1;
    }
  }
  const entrySpeed = Math.hypot(entryVx, impact);
  s.splashCooldown = Math.max(0, s.splashCooldown - h);
  if (overlappingWater) {
    if (!s.waterContact && s.splashCooldown === 0 && entrySpeed > 65) {
      burst(s, contactX / overlappingWater, contactY / overlappingWater, 24, entryVx * 0.6, -Math.max(210, entrySpeed * 0.85), 2, 10 + Math.floor(Math.random() * 3));
      s.waterContact = true;
      s.splashCooldown = 0.12;
    }
  } else {
    s.waterContact = false;
  }
  for (let y = Math.max(0, Math.floor((s.y - 1) / CELL)); y <= Math.min(GRID - 1, Math.floor((s.y + 16) / CELL)); y++) {
    for (let x = Math.max(0, Math.floor((s.x - 1) / CELL)); x <= Math.min(GRID - 1, Math.floor((s.x + 16) / CELL)); x++) {
      const i = y * GRID + x;
      if (s.grid[i] === 2 && s.heldWater < 15) {
        changeMaterial(s,i,0);
        s.heldWater++;
      }
    }
  }
  for (let y = Math.max(0, Math.floor(s.y / CELL)); y <= Math.min(GRID - 1, Math.floor((s.y + 15) / CELL)); y++) {
    for (let x = Math.max(0, Math.floor(s.x / CELL)); x <= Math.min(GRID - 1, Math.floor((s.x + 15) / CELL)); x++) {
      if (s.grid[y * GRID + x] !== 2) continue;
      immersed = Math.min(1, immersed + 1 / 64);
      {
        let destination = -1;
        for (let r = 1; r <= 12 && destination < 0; r++) {
          for (let dx = -r; dx <= r && destination < 0; dx++) for (const dy of [-r, 0, r]) {
            const nx = x + dx, ny = y + dy;
            if (nx >= 0 && nx < GRID && ny >= 0 && ny < GRID && !s.grid[ny * GRID + nx] && !s.dynamicRock[ny * GRID + nx] && !insidePlayer(s, nx, ny)) {destination = ny * GRID + nx; break;}
          }
        }
        if (destination >= 0) {changeMaterial(s,destination,2); changeMaterial(s,y*GRID+x,0);}
      }
    }
  }
  s.submerged += (immersed - s.submerged) * Math.min(1, h * 10);
  if (s.heldWater > 0) {
    s.dripTime += h;
    if (s.dripTime >= 0.35) {
      const candidates = [
        {x: s.x + 4, y: s.y + 18}, {x: s.x + 12, y: s.y + 18},
        {x: s.x - 2, y: s.y + 14}, {x: s.x + 18, y: s.y + 14}
      ];
      const start = Math.floor(Math.random() * candidates.length);
      for (let n = 0; n < candidates.length; n++) {
        const p = candidates[(start + n) % candidates.length];
        const gx = Math.floor(p.x / CELL), gy = Math.floor(p.y / CELL);
        if (gx < 0 || gx >= GRID || gy < 0 || gy >= GRID || s.grid[gy * GRID + gx] || s.dynamicRock[gy * GRID + gx] || insidePlayer(s, gx, gy)) continue;
        s.flying.push({x: p.x, y: p.y, vx: s.vx * 0.2, vy: Math.max(20, s.vy * 0.2), type: 2, pickupDelay: 0.4, settleDelay: 0.08});
        s.heldWater--;
        s.dripTime = 0;
        break;
      }
      s.dripTime = Math.min(s.dripTime, 0.35);
    }
  } else s.dripTime = 0;
  s.accumulator += h;
  while (s.accumulator >= 1 / 60) {stepMaterials(s, 1 / 60); s.accumulator -= 1 / 60;}
};

const preservedGameDefinition = function preservedGameDefinition(){return ({cameraMode:'none',
  title: 'Square Platformer',
  accent: '#E60012',
  canvas: '#playfield',
  states: [{name: 'main', role: ['initial', 'active']}],
  initial: 'main',
  clockPhases: ['main'],
  createState(c) {
    return {
      ...makeMaterials(),
      bullets: [],
      magicImpacts: [],
      shots: 0,
      magicHits: 0,
      converted: 0,
      x: 48,
      y: 704,
      vx: 0,
      vy: 0,
      grounded: true,
      supportVx: 0,
      supportVy: 0,
      coyote: 0.1,
      jumps: 0,
      held: {}
    };
  },
  setup(c) {
    readTune();
    c.bind('#left', {role: 'button', as: 'left', keys: ['ArrowLeft']});
    c.bind('#right', {role: 'button', as: 'right', keys: ['ArrowRight']});
    c.bind('#up', {role: 'button', as: 'up', keys: ['ArrowUp']});
    c.bind('#down', {role: 'button', as: 'down', keys: ['ArrowDown']});
    c.bind('#a', {role: 'button', as: 'a', keys: ['Space', 'KeyX']});
    c.bind('#b', {role: 'button', as: 'b', keys: ['KeyZ']});
    c.bind('#x', {role: 'button', as: 'x', keys: ['KeyS']});
    c.bind('#y', {role: 'button', as: 'y', keys: ['KeyA']});
    c.bind('#lb', {role: 'button', as: 'lb', keys: ['KeyQ']});
    c.bind('#rb', {role: 'button', as: 'rb', keys: ['KeyE']});
    c.bind('#playfield', {role: 'surface', as: 'magic', tap: 'shoot', keys: ['KeyF']});
    c.on('press', event => {
      if (event.target !== 'magic') return;
      if (!Number.isFinite(event.elementX) || !Number.isFinite(event.elementY)) {
        c.actions.shoot(c);
        return;
      }
      const camera = cameraFor(c.state);
      const scale = Math.min(c.width, c.height) / camera.size;
      if (scale <= 0) return;
      const left = Math.floor((c.width - camera.size * scale) / 2);
      const top = Math.floor((c.height - camera.size * scale) / 2);
      const x = (event.elementX * c.width - left) / scale;
      const y = (event.elementY * c.height - top) / scale;
      shoot(c, camera.x + x, camera.y + y);
    });
    paint(c);
  },
  onPhase(name, c) {
    paint(c);
  },
  onReset(c) {
    paint(c);
  },
  update(dt, c) {
    for (const name of controlNames) {
      c.state.held[name] = Boolean(c.input.buttonsHeld[name]);
    }
    if (c.input.buttons.a) {
      c.actions.jump(c);
    }
    const elapsed = Math.min(dt, 0.08);
    const steps = Math.max(1, Math.ceil(elapsed / (1 / 120)));
    for (let i = 0; i < steps; i += 1) {
      simulate(elapsed / steps, c);
    }
    updateRigidConnectivity(c.state);
    paint(c);
  },
  render({ctx, width, height}, c) {
    const now=performance.now();
    if(fpsPrevious) {
      const elapsed=now-fpsPrevious;
      if(elapsed>0 && elapsed<1000) {fpsElapsed+=elapsed;fpsFrames++;}
      else {fpsElapsed=0;fpsFrames=0;}
      if(fpsElapsed>=500) {measuredFps=Math.round(fpsFrames*1000/fpsElapsed);fpsElapsed=0;fpsFrames=0;}
    }
    fpsPrevious=now;
    ctx.fillStyle = '#EFEDE8';
    ctx.fillRect(0, 0, width, height);
    const camera = cameraFor(c.state);
    const scale = Math.min(width, height) / camera.size;
    const left = Math.floor((width - camera.size * scale) / 2);
    const top = Math.floor((height - camera.size * scale) / 2);
    const rect = (x, y, w, h) => {
      const x1 = Math.round(left + (x - camera.x) * scale);
      const y1 = Math.round(top + (y - camera.y) * scale);
      const x2 = Math.round(left + (x + w - camera.x) * scale);
      const y2 = Math.round(top + (y + h - camera.y) * scale);
      ctx.fillRect(x1, y1, x2 - x1, y2 - y1);
    };
    ctx.imageSmoothingEnabled = false;
    const pixels = materialPixels.data, grid = c.state.grid;
    let materialImageChanged=false;
    const gx0=Math.max(0,Math.floor(camera.x/CELL)),gy0=Math.max(0,Math.floor(camera.y/CELL));
    const gx1=Math.min(GRID,Math.ceil((camera.x+camera.size)/CELL)+1),gy1=Math.min(GRID,Math.ceil((camera.y+camera.size)/CELL)+1);
    for(let gy=gy0;gy<gy1;gy++) for(let gx=gx0;gx<gx1;gx++) {
      const i=gy*GRID+gx;
      const type = grid[i], p = i * 4;
      if(renderedMaterials[i]===type) continue;
      renderedMaterials[i]=type;
      materialImageChanged=true;
      const shade = (i * 17 + Math.floor(i / GRID) * 13) % 19;
      const color=MATERIAL_COLORS[type];
      pixels[p] = color[0]+shade;
      pixels[p + 1] = color[1]+shade;
      pixels[p + 2] = color[2]+shade;
      pixels[p + 3] = type ? 255 : 0;
    }
    if(materialImageChanged) materialContext.putImageData(materialPixels,0,0,gx0,gy0,gx1-gx0,gy1-gy0);
    ctx.save();
    ctx.beginPath();
    ctx.rect(left, top, camera.size * scale, camera.size * scale);
    ctx.clip();
    ctx.drawImage(materialCanvas,gx0,gy0,gx1-gx0,gy1-gy0,left+(gx0*CELL-camera.x)*scale,top+(gy0*CELL-camera.y)*scale,(gx1-gx0)*CELL*scale,(gy1-gy0)*CELL*scale);
    for (const rock of c.state.rockBodies) {
      const position=rock.body.getPosition();
      const bounds=rock.chunkBounds;
      if(bounds && (bounds[2]*CELL<camera.x || bounds[0]*CELL>camera.x+camera.size || bounds[3]*CELL<camera.y || bounds[1]*CELL>camera.y+camera.size)) continue;
      ctx.save();
      ctx.translate(left+(position.x*PHYSICS_SCALE-camera.x)*scale,top+(position.y*PHYSICS_SCALE-camera.y)*scale);
      ctx.rotate(rock.body.getAngle());
      ctx.scale(scale,scale);
      for(const p of rock.cells) {
        const shade=p.shade;
        ctx.fillStyle=materialColor(p.type,shade);
        ctx.fillRect(p.x*CELL,p.y*CELL,CELL,CELL);
      }
      ctx.restore();
    }
    for (const p of c.state.flying) {
      ctx.fillStyle = p.type === 1 ? '#DEB363' : '#328FDF';
      rect(p.x - 1, p.y - 1, 2, 2);
    }
    for (const b of c.state.bullets) {
      ctx.fillStyle = '#C6A2FA';
      for (let i = 1; i <= 4; i++) rect(b.x - b.vx / 320 * i * 2 - 1, b.y - b.vy / 320 * i * 2 - 1, 2, 2);
      ctx.fillStyle = '#8649DA';
      rect(b.x - 2, b.y - 2, 4, 4);
      ctx.fillStyle = '#FFFFFF';
      rect(b.x - 0.5, b.y - 0.5, 1, 1);
    }
    for (const hit of c.state.magicImpacts) {
      const radius = 2 + (1 - hit.life / 0.25) * 5;
      ctx.fillStyle = '#8649DA';
      for (let i = 0; i < 8; i++) rect(hit.x + Math.cos(i * Math.PI / 4) * radius - 0.5, hit.y + Math.sin(i * Math.PI / 4) * radius - 0.5, 1, 1);
    }
    ctx.fillStyle = c.accent || '#E60012';
    rect(Math.round(c.state.x), Math.round(c.state.y), 16, 16);
    ctx.fillStyle = '#328FDF';
    for (let i = 0; i < c.state.heldWater; i++) {
      const edge = Math.floor(i / 5), offset = 1 + (i % 5) * 3;
      const dx = edge === 0 ? 0 : edge === 1 ? 14 : offset;
      const dy = edge === 2 ? 14 : offset;
      rect(Math.round(c.state.x) + dx, Math.round(c.state.y) + dy, 2, 2);
    }
    ctx.restore();
    ctx.fillStyle = '#4A4A4A';
    ctx.font = `${Math.max(8, Math.round(6 * scale))}px monospace`;
    ctx.textBaseline = 'top';
    ctx.fillText(`x:${Math.round(c.state.x)} y:${Math.round(c.state.y)}`, left + 6 * scale, top + 6 * scale);
    ctx.fillText(`Water: ${c.state.heldWater}/15`, left + 6 * scale, top + 16 * scale);
    ctx.textAlign = 'right';
    ctx.font = '14px monospace';
    ctx.fillText(`FPS: ${measuredFps || '…'}`, width - 12, 12);
    ctx.textAlign = 'left';
  },
  inspect(c) {
    return {
      fps: measuredFps,
      worldSeed:c.state.seed,
      terrainPinCount:c.state.terrainPins.size,
      rigidMaterials:['stone','grass','dirt','wood','leaves'],
      chunkPixels: CHUNK_PIXELS,
      chunkUpdateRadius: CHUNK_UPDATE_RADIUS,
      chunkUpdateWidth: CHUNK_UPDATE_RADIUS*2+1,
      totalChunks: CHUNKS*CHUNKS,
      activeChunks: c.state.chunkAwake.reduce((n,v)=>n+Number(v>0),0),
      simulatedChunks: c.state.chunkScanned,
      x: c.state.x,
      y: c.state.y,
      velocityX: c.state.vx,
      velocityY: c.state.vy,
      grounded: c.state.grounded,
      playerPhysics: c.state.playerRockCollider ? c.state.playerRockCollider.getType() : 'pending',
      jumps: c.state.jumps,
      airborneParticles: c.state.flying.length,
      activeBullets: c.state.bullets.length,
      shots: c.state.shots,
      magicHits: c.state.magicHits,
      convertedParticles: c.state.converted,
      pendingSupportChecks: (c.state.supportSeeds?.size || 0)+Number(Boolean(c.state.supportSearch)),
      supportSearchCells: c.state.supportSearch?.cells.length || 0,
      launchedParticles: c.state.launched,
      materialTick: c.state.tick,
      submerged: c.state.submerged,
      heldWater: c.state.heldWater,
      waterCapacity: 15,
      held: {...c.state.held},
      worldWidth: WORLD,
      worldHeight: WORLD,
      camera: cameraFor(c.state),
      rockParticles: c.state.grid.reduce((count, type) => count + Number(type === 3), 0),
      disconnectedRockParticles: c.state.disconnectedRockCount,
      rigidBodyCount: c.state.rockBodies.length,
      rigidBodyTriangles: c.state.rockBodies.reduce((n,r)=>n+r.triangles,0),
      rigidBodies: c.state.rockBodies.map(r=>({id:r.id,x:r.body.getPosition().x*PHYSICS_SCALE,y:r.body.getPosition().y*PHYSICS_SCALE,angle:r.body.getAngle(),particles:r.cells.length})),
      mapLayout: 'fixed-hillside-procedural-caves',
      entrance: {x:192,y:692},
      rockRigid: true
    };
  },
  interactable: [
    {id: 'shoot', selector: '#playfield', kind: 'surface', action: 'tap', expect: 'field_change'},
    {id: 'left', selector: '#left', kind: 'button', action: 'tap'},
    {id: 'right', selector: '#right', kind: 'button', action: 'tap'},
    {id: 'up', selector: '#up', kind: 'button', action: 'tap'},
    {id: 'down', selector: '#down', kind: 'button', action: 'tap'},
    {id: 'a', selector: '#a', kind: 'button', action: 'tap', expect: 'field_change'},
    {id: 'b', selector: '#b', kind: 'button', action: 'tap'},
    {id: 'x', selector: '#x', kind: 'button', action: 'tap'},
    {id: 'y', selector: '#y', kind: 'button', action: 'tap'},
    {id: 'lb', selector: '#lb', kind: 'button', action: 'tap'},
    {id: 'rb', selector: '#rb', kind: 'button', action: 'tap'}
  ],
  actions: {
    shoot(c) {
      const camera = cameraFor(c.state);
      shoot(c, camera.x + camera.size / 2, camera.y + camera.size / 2);
    },
    jump(c) {
      jump(c);
      paint(c);
    }
  },
  refresh(c) {
    readTune();
    paint(c);
  }
});};

const definition=preservedGameDefinition();
const canvas=document.getElementById('playfield'),ctx=canvas.getContext('2d');
const input={buttons:{},buttonsHeld:{}},listeners={},bindings=[],contacts=new Map();
const c={state:null,input,actions:definition.actions,accent:definition.accent,width:0,height:0,
  bind(selector,options){
    const element=document.querySelector(selector);
    bindings.push({element,options});
    element.style.touchAction='none';
    element.addEventListener('pointerdown',event=>{
      element.setPointerCapture(event.pointerId);contacts.set(event.pointerId,options.as);
      if(options.role==='button'){input.buttons[options.as]=true;input.buttonsHeld[options.as]=true;}
      else{const box=element.getBoundingClientRect();for(const fn of listeners.press||[])fn({target:options.as,elementX:(event.clientX-box.left)/box.width,elementY:(event.clientY-box.top)/box.height});}
      event.preventDefault();
    });
    const release=event=>{contacts.delete(event.pointerId);if(![...contacts.values()].includes(options.as))input.buttonsHeld[options.as]=false;};
    element.addEventListener('pointerup',release);element.addEventListener('pointercancel',release);
  },
  on(name,fn){(listeners[name]||(listeners[name]=[])).push(fn);}
};
function resize(){const box=canvas.getBoundingClientRect();c.width=box.width;c.height=box.height;const dpr=devicePixelRatio||1;canvas.width=Math.round(box.width*dpr);canvas.height=Math.round(box.height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);}
new ResizeObserver(resize).observe(canvas);resize();
c.state=definition.createState(c);definition.setup(c);
addEventListener('keydown',event=>{if(event.repeat)return;for(const {options} of bindings){if(!(options.keys||[]).includes(event.code))continue;event.preventDefault();if(options.role==='button'){input.buttons[options.as]=true;input.buttonsHeld[options.as]=true;}else c.actions.shoot(c);}});
addEventListener('keyup',event=>{for(const {options} of bindings)if((options.keys||[]).includes(event.code)){input.buttonsHeld[options.as]=false;event.preventDefault();}});
addEventListener('blur',()=>{input.buttons={};input.buttonsHeld={};contacts.clear();paint(c);});
let previous=0;
function frame(now){const dt=previous?Math.min((now-previous)/1000,.08):0;previous=now;if(c.width>0&&c.height>0){definition.update(dt,c);input.buttons={};definition.render({ctx,width:c.width,height:c.height},c);}requestAnimationFrame(frame);}
requestAnimationFrame(frame);
